-----------------------------------------------------------------------------
Polytech Nantes
2013-2014 INFO5
-----------------------------------------------------------------------------
Projet de Recherche et d�veloppement
Sujet 48 Magic Portrait
-----------------------------------------------------------------------------
Etudiants:
Pierre-Yves HERVO
Paul-Fran�ois JEAU
-----------------------------------------------------------------------------

Ce d�p�t est aussi sur le repository Git suivant:
https://github.com/phervo/ProjetRD48

Ce dossier contient deux sous-r�pertoires:
- Livrables/: contient tous les documents g�n�r�s lors du projet
- Codes/    : contient toute notre production logicielle

Le r�pertoire Codes contient lui-aussi deux sous-r�pertoires:
- C++/          : contient le projet Visual Studio ainsi que le code source pour g�n�rer l'ex�cutable du module de Lissage de peau;
- MagicPortrait/: contient les scripts Matlab, les scripts Batchs et les images de test.
Ainsi que les �l�ments suivants: 
- images/                             : contient des exemples d'images non trait�es
- images_resultats/                   : contient des exemples d'images obtenues � l'issue du traitement
- haarcascade_frontalface_default.xml : le fichier .xml utilis� pour chercher la boite englobante (n�c�ssaire pour le code C++)
- magicportrait.exe                   : l'ex�cutable g�n�r� avec Visual Studio pour le module 1


Pr�requis : 
-----------
Les diff�rents codes C++ d�pendent de la biblioth�que OpenCV (version 2.4.7 lors du d�veloppement)
Les codes Matlab ont �t� test�s avec un Matlab R2013a 64b (8 1.0 604) muni de la Computer Vision Toolbox (5.2).



Comment utiliser nos scripts ?

Dans le dossier MagicPortrait sont plac�s plusieurs scripts batchs permettant de lancer le traitement.

Il existe 3 r�pertoires dans lesquels placer les images � tester : 

00_images_cibles                                 : images originales
01_images_apres_lissage_peau                     : images � l'issue du traitement du module 1
02_images_apres_augmentation_profondeur_champ    : images � l'issue du traitement du module 2
03_images_apres_correction_contraste_luminosite  : images � l'issue du traitement du module 3



Il existe 8 scripts batchs pour effectuer des exp�rimentations: 

- Pour le module 1: Lissage de la peau

nom du bat        : magicportrait_enhanceskin_files_in_directory
comment le lancer : magicportrait_enhanceskin_files_in_directory.bat <repertoire_contenant_images_cibles> <repertoire_destination>
explication       : ce bat lance l'ex�cutable g�n�r� sous Visual Studio r�alisant le module 1

nom du bat        : magicportrait_auto_etape1
comment le lancer : magicportrait_auto_etape1.bat
explication       : ce bat lance automatiquement "magicportrait_enhanceskin_files_in_directory.bat 00_images_cibles 01_images_apres_lissage_peau" 


- Pour le module 2: Augmentation de la profondeur de champ

nom du bat        : magicportrait_enhancebackground_files_in_directory
comment le lancer : magicportrait_enhancebackground_files_in_directory.bat <repertoire_contenant_images_cibles> <repertoire_destination>
explication       : lance le script Matlab responsable de l'augmentation de la profondeur de champ.

nom du bat        : magicportrait_auto_etape2
comment le lancer : magicportrait_auto_etape2.bat
explication       : ce bat lance automatiquement "magicportrait_enhancebackground_files_in_directory.bat 01_images_apres_lissage_peau 02_images_apres_augmentation_profondeur_champ" 


- Pour le module 3: Correction du contraste et de la luminosit� 

nom du bat        : magicportrait_enhanceconditions_files_in_directory
comment le lancer : magicportrait_enhanceconditions_files_in_directory.bat <repertoire_contenant_images_cibles> <repertoire_destination>
explication       : lance le script Matlab responsable de la correction du constrate et de la luminosit�.

nom du bat        : magicportrait_auto_etape3
comment le lancer : magicportrait_auto_etape3.bat
explication       : ce bat lance automatiquement "magicportrait_enhanceconditions_files_in_directory.bat 02_images_apres_augmentation_profondeur_champ 03_images_apres_correction_contraste_luminosite" 



- Pour un traitement d'une image en particulier : 

nom du bat        : magicportrait_traitement_complet_une_image
comment le lancer : magicportrait_traitement_complet_une_image.bat <nom_image_originale> <nom_image_apres_module1> <nom_image_apres_module2> <nom_image_apres_module3>
explication       : 

nom du bat        : magicportrait_traiter_image
comment le lancer : magicportrait_traiter_image.bat
explication       : ce bat lance automatiquement "magicportrait_traitement_complet_une_image.bat 00_images_cibles\nom_image 01_images_apres_lissage_peau\nom_image_retour1 02_images_apres_augmentation_profondeur_champ\nom_image_retour2 03_images_apres_correction_contraste_luminosite\nom_image_retour3"



Voici un exemple du lancement du script traiter_image apr�s que le placement de l'image px.jpg dans le dossier 00_images_cibles/
call magicportrait_traitement_complet_une_image.bat 00_images_cibles\px.jpg 01_images_apres_lissage_peau\px_lisse.jpg 02_images_apres_augmentation_profondeur_champ\px_lisse_prof.jpg 03_images_apres_correction_contraste_luminosite\px_lisse_prof_contraste.jpg

Les r�sultats interm�diaires sont enregistr�s dans les r�pertoires 01*, 02* puis 03*.
Les r�sultats finaux sont aussi ceux du dossier 03*.


